from flask import Flask, request, jsonify
import joblib

app = Flask(__name__)

model = joblib.load('D:\\New folder\\model.txt')



def extract_client_from_request(req_data):
    client = []
    Processor = req_data['Processor']
    screen = req_data['Screen Size(inch)']
    ram = req_data['RAM(GB)']
    graphics = req_data['Graphics Card']
    ssd = req_data['SSD(GB)']
    hdd = req_data['HDD(GB)']
    os = req_data['OS']
    normal = req_data['Normal']

    # evaluation
    try:
        if ssd > 128 and ssd <= 4000:
            pass
        else:
            return jsonify({"ssd error": "please number betwwen 128, 40000"})

    except:
        return jsonify({"ssd error": "please number betwwen 128, 40000"})


    try:
        if hdd > 128 and hdd <= 4000:
            pass
        else:
            return jsonify({"hdd error": "please number betwwen 128, 40000"})

    except:
        return jsonify({"hdd error": "please number betwwen 128, 40000"})


    try:
        if screen >= 8 and screen <= 30:
            pass
        else:
            return jsonify({"screen error": "please inter number betwwen 8, 30"})

    except:
        return jsonify({"screen error": "please inter number betwwen 8, 40000"})


    try:
        if type(ram) == int:
            if ram >= 2 and ram <= 64:
                pass
        else:
            return jsonify({"ram error": "please number betwwen 2, 64"})

    except:
        return jsonify({"ram error": "please number betwwen 2, 64"})


    


    return client



@app.route('/predict', methods=['POST'])
def predict():
    client = [extract_client_from_request(request.json)]
    prediction = model.predict(client)[0]
    return jsonify({'price is': prediction})


if __name__ == '__main__':
    app.run()
